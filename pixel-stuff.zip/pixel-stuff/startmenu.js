function openStartMenu() {

}

function toggleClass(id, className) {
    const element = document.getElementById(id);
    if (!element) return;

    if (element.classList.contains(className)) {
        element.classList.remove(className);
        return;
    } 
    
    element.classList.add(className);
}